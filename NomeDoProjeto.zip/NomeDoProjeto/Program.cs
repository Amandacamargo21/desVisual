﻿using System;

namespace NomeDoProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ex01.Renderizar();
            // Ex02.Renderizar();
            // Ex03.Renderizar();
            // Ex04.Renderizar();
            // Ex05.Renderizar();
            Ex06.Renderizar();
        }

    }
}
