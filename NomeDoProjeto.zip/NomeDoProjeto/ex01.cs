using System;

namespace NomeDoProjeto 
{
    class Ex01{
        public static void Renderizar() {
            //EXERCICIO 1

            //imprimir mensagem no terminal
            Console.WriteLine("Digite a altura: ");
            int altura = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Digite a largura: ");
            int largura = Convert.ToInt32(Console.ReadLine());

            int area = altura * largura;

            Console.WriteLine($"Área: { area } ");

        }
    }
}