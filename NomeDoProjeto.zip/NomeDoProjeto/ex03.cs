using System;

namespace NomeDoProjeto {
    class Ex03 {
        public static void Renderizar(){
            //EXERCICIO 3
            Console.WriteLine("Digite dois valores: ");
            int valorUm = Convert.ToInt32(Console.ReadLine());
            int valorDois = Convert.ToInt32(Console.ReadLine());

                if (valorUm > valorDois) {
                    Console.WriteLine($"Maior valor: {valorUm}");
                }
                else {
                    Console.WriteLine($"Maior valor: {valorDois}");
                }
        }
    }
}