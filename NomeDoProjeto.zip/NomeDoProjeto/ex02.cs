using System;

namespace NomeDoProjeto {
    class Ex02{
        public static void Renderizar(){
            // EXERCICIO 2

            Console.WriteLine("Digite um valor em reais: ");
            double reais = Convert.ToDouble(Console.ReadLine());

            const double dolar = 5.16;
            const double euro = 5.31;
            const double peso = 0.04;

            double conversaoDolar = dolar * reais;
            double conversaoEuro = euro * reais;
            double conversaoPeso = peso * reais;

            Console.WriteLine($"\nDólar: {conversaoDolar} \n Euro: {conversaoEuro} \n Peso: {conversaoPeso}");
        }
    }
}