using System;

namespace NomeDoProjeto {
    class Ex05{
        public static void Renderizar(){
            
        }
    }
}