using Microsoft.AspNetCore.Mvc;

namespace WebApi.UsuarioControler
{
    [Route("api/usuario")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        //gera requisição via GET:/api/usuario/listar
        [HttpGet]
        [Route("Listar")]
        public IActionResult Listar()
        {
            return Ok("oi");
        }
    }
}